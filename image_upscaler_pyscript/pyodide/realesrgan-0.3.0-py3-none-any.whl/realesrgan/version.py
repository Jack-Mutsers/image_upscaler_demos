# GENERATED VERSION FILE
# TIME: Tue Sep 20 11:49:50 2022
__version__ = '0.3.0'
__gitsha__ = 'fa4c8a0'
version_info = (0, 3, 0)
